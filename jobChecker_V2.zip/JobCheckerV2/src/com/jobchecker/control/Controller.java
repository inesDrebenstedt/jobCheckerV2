package com.jobchecker.control;

import com.jobchecker._aux.StringTools;

public class Controller {
	
	private String results;

	public Controller (String title, String link, String htmlMarker, String searchMarker)
	{
		HtmlReader myReader = new HtmlReader(title, link, htmlMarker, searchMarker);
		this.results = myReader.getHTMLresult(link);
		StringTools.countJobs(title, this.results, htmlMarker, searchMarker);
		FileMaker fileMaker =  new FileMaker();
		fileMaker.makeFile(title, link, this.results, htmlMarker, searchMarker);		
	}
	
}
