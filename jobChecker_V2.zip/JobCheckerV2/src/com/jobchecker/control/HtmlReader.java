package com.jobchecker.control;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class HtmlReader {
	
	private String link ; // "https://www.lyth.de/jobs.html";
	private String htmlJobMarker; // "OffeneStellen";
	private String searchMarker = "";
	//int jobCounts = 0;
	private String readerTitle;

	
	public HtmlReader()
	{}
	
	public HtmlReader(String readerTitle, String link, String htmlJobMarker, String searchMarker)
	{
		this.readerTitle = readerTitle;
		this.link = link;
		this.htmlJobMarker = htmlJobMarker;
	}
	
	
	public String getHTMLresult(String link)
	{		
		URL url = null;
		Scanner sc = null;
		String result = "";
		try {
			url =  new URL(link);//new URL("https://www.lyth.de/jobs.html");			 
			try {
				//Retrieving the contents of the specified page
				sc = new Scanner(url.openStream());
			} catch (IOException e) {				
				e.printStackTrace();
			}

	      //Instantiating the StringBuffer class to hold the result
	      StringBuffer sb = new StringBuffer();
	      while(sc.hasNext()) {
	         sb.append(sc.next());
	         //System.out.println(sc.next());
	      }
	      //Retrieving the String from the String Buffer object
	      result = sb.toString();
	      //System.out.println(result);
	      //Removing the HTML tags
	      result = result.replaceAll("<[^>]*>", "");
	      //System.out.println("Content of the web page: "+ result);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}	
		
		return result;
	}

	
	public String getHtmlJobMarker()
	{		
		return this.htmlJobMarker;
	}
	
	
	public String getReaderTitle()
	{		
		return this.readerTitle;
	}
	
	
	public String getLink()
	{		
		return this.link;
	}

}
