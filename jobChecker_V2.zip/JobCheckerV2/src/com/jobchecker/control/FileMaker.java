package com.jobchecker.control;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import com.jobchecker._aux.StringTools;



public class FileMaker {
	
	public void makeFile(String readerTitle, String link, String result, String htmlJobMarker, String searchMarker)
	{
		String outStr = StringTools.countToString(readerTitle, link, htmlJobMarker, searchMarker);
	
		 try {
	            File file = new File(readerTitle);
	            file.setWritable(true);
	            file.setReadable(true);
	         BufferedWriter out = new BufferedWriter(new FileWriter(file, true));
	         out.append("\n" + outStr);
	         out.close();
	         BufferedReader in = new BufferedReader(new FileReader(readerTitle));
	         String str;
	         
	         while ((str = in.readLine()) != null) {
	            System.out.println(str);
	         }
	         in.close();
	      }	      
	      catch (IOException e) {
	         System.out.println("exception occured"+ e);
	      }	
		 StringTools.jobCounts = 0;
	}


}
