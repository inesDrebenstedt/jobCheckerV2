package com.jobchecker.main;

import com.jobchecker.control.Controller;

public class Main {

	public static void main(String[] args) {
		
		/*
		 * @param
		 * Name or title of the employer of your choice, URL, hand-picked keyword marker of their job page, hand-picked keyword marker of their job results page
		 */
		Controller c1 = new Controller("Lyth", "https://www.lyth.de/jobs.html", "OffeneStellen", "MEHRERFAHREN");
		System.out.println("=============================================================");
		
		Controller c2 = new Controller("Axitera", "https://axitera.de/stellenboerse/", "w-actionbox-text", "(m/w/d)");
		System.out.println("=============================================================");
		
		Controller c3 = new Controller("Cofinpro", "https://cofinpro.de/karriere/technologieberater/jobs/", "Jobangebote", "Vollzeit");
		System.out.println("=============================================================");
	}

}
