package com.jobchecker._aux;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class StringTools {
	
	public static int jobCounts;// Number of jobs recognized by marker string in html
	static String htmlJobMarker; // "OffeneStellen";	

	public static void countJobs(String title, String result, String htmlJobMarker, String searchMarker)
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		String[] testStr = result.split(htmlJobMarker);
		String[] resultStr ;
		for(int i = 0; i < testStr.length; i++)
		{
			boolean isValid = (testStr[i] != null );
			if(isValid)
			{
				resultStr = testStr[i].split(searchMarker);
				for(int j =  0 ; j < resultStr.length-2; j++)
				{			
					System.out.println(" ---> " + resultStr[j]); 
					jobCounts++;
				}
			}
		}		
		System.out.println(" countJobs(). # of jobs listed for employer:  " + title + ", " + adjustJobcountByEmployer(title, jobCounts) + " on " + dtf.format(now));
	}
	
	
	public static String countToString(String title, String result,  String htmlJobMarker, String searchMarker)
	{
		String output = "";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		String[] htmlResultStr = result.split(htmlJobMarker);
		String[] resultStr ;
		
		for(int i = 0; i < htmlResultStr.length; i++)
		{
			boolean isValid = (htmlResultStr[i] != null );
			if(isValid)
			{
				resultStr = htmlResultStr[i].split(searchMarker);
				for(int j =  0 ; j < resultStr.length-2; j++)
				{			
					System.out.println(" ---> " + resultStr[j]);
					jobCounts++;
				}				
			}
		}

		output += "\n" +  " # of jobs listed for employer:  " + title + ", "
		+ adjustJobcountByEmployer(title, jobCounts)
		+ " on " + dtf.format(now) + "\n";
		
		return output;
	}
	
	
	public static int adjustJobcountByEmployer(String employerTitle, int currentJobcount)
	{		
		if(employerTitle.matches("Axitera"))
		{
			currentJobcount = currentJobcount - 1;
		}
		return currentJobcount;
	}
	

}
